from pymongo import MongoClient, ASCENDING, DESCENDING, errors
from datetime import datetime, timedelta
import time
import os
from dotenv import load_dotenv

# Load environment variables for security
load_dotenv()

class MongoDBManager:
    def __init__(self, mongo_uri=None, db_name=None):
        # Use environment variables if not provided explicitly
        self.mongo_uri = mongo_uri or os.getenv('MONGO_URI')
        self.db_name = db_name or os.getenv('MONGO_DB_NAME', 'users')
        self.client = None
        self.db = None
        self.connect_to_db()

    def connect_to_db(self):
        """Connect to MongoDB and handle connection issues gracefully."""
        try:
            self.client = MongoClient(self.mongo_uri, serverSelectionTimeoutMS=5000)
            self.db = self.client[self.db_name]
            self.client.server_info()  # Force connection to trigger exceptions if any
            print("🔗 Successfully connected to MongoDB!")
            self.setup_database()
        except errors.ServerSelectionTimeoutError as err:
            print(f"❌ Connection failed: {err}")
            print("⏳ Retrying connection in 5 seconds...")
            time.sleep(5)
            self.connect_to_db()

    def setup_database(self):
        """Ensure necessary collections and indexes are set up."""
        print("🔄 Setting up the database and ensuring collections and indexes are in place...")
        self.ensure_collection("user_logs")
        self.ensure_collection("card_checks")
        self.ensure_ttl_index("user_logs", "timestamp", 3600)  # TTL index for 1 hour expiration
        print("✅ Database setup complete.")

    def ensure_collection(self, collection_name):
        """Ensure the collection exists, create it if not."""
        if collection_name not in self.db.list_collection_names():
            self.db.create_collection(collection_name)
            print(f"✅ Collection '{collection_name}' created.")
        else:
            print(f"ℹ️ Collection '{collection_name}' already exists.")

    def ensure_ttl_index(self, collection_name, field, ttl_seconds=3600):
        """Create or update a TTL index on the specified field."""
        try:
            collection = self.db[collection_name]
            collection.create_index([(field, ASCENDING)], expireAfterSeconds=ttl_seconds)
            print(f"✅ TTL index created on {collection_name}.{field} with {ttl_seconds} seconds expiration.")
        except Exception as e:
            print(f"❌ Error creating TTL index: {str(e)}")

    def insert_log(self, collection_name, log_data):
        """Insert a log entry into the specified collection."""
        try:
            collection = self.db[collection_name]
            log_data['timestamp'] = datetime.utcnow()
            collection.insert_one(log_data)
            print(f"📝 Log inserted into {collection_name}.")
        except errors.WriteError as we:
            print(f"❌ Write Error: {str(we)}")
        except Exception as e:
            print(f"❌ Error inserting log: {str(e)}")

    def get_recent_logs(self, collection_name, user_id, limit=10):
        """Retrieve recent logs for a specific user, with a limit on the number of results."""
        try:
            collection = self.db[collection_name]
            return list(collection.find({"user_id": user_id}).sort("timestamp", DESCENDING).limit(limit))
        except errors.PyMongoError as err:
            print(f"❌ Error fetching logs: {str(err)}")
            return []

    def auto_fix_errors(self, collection_name):
        """Auto-detect and fix any MongoDB-related issues, such as missing indexes."""
        try:
            collection = self.db[collection_name]
            indexes = collection.index_information()
            if 'timestamp_1' not in indexes:
                print(f"⚠️ Missing index on 'timestamp'. Re-creating TTL index.")
                self.ensure_ttl_index(collection_name, 'timestamp', 3600)
            else:
                print("✅ All necessary indexes are present.")
        except Exception as e:
            print(f"❌ Error during auto-fix: {str(e)}")

    def update_user_data(self, collection_name, user_id, new_data):
        """Update or insert user data in the specified collection."""
        try:
            collection = self.db[collection_name]
            collection.update_one({"user_id": user_id}, {"$set": new_data}, upsert=True)
            print(f"✅ Data updated for user_id: {user_id}.")
        except errors.PyMongoError as err:
            print(f"❌ Error updating user data: {str(err)}")

    def delete_user_data(self, collection_name, user_id):
        """Delete a user's data from the specified collection."""
        try:
            collection = self.db[collection_name]
            result = collection.delete_one({"user_id": user_id})
            if result.deleted_count > 0:
                print(f"🗑️ User data deleted for user_id: {user_id}.")
            else:
                print(f"⚠️ No data found to delete for user_id: {user_id}.")
        except errors.PyMongoError as err:
            print(f"❌ Error deleting user data: {str(err)}")

    def log_card_check(self, collection_name, user_id, card_info, status):
        """Log the result of a card check."""
        log_data = {
            "user_id": user_id,
            "card_info": card_info,
            "status": status,
            "timestamp": datetime.utcnow()
        }
        self.insert_log(collection_name, log_data)

    def close_connection(self):
        """Close the MongoDB connection safely."""
        if self.client:
            self.client.close()
            print("🔌 MongoDB connection closed.")


# Example usage:
if __name__ == "__main__":
    db_manager = MongoDBManager()  # Using environment variables

    # Auto-fix any detected issues
    db_manager.auto_fix_errors("user_logs")

    # Log a card check result
    db_manager.log_card_check("card_checks", user_id=12345, card_info="4269123456781234|12|2025|123", status="declined")

    # Retrieve recent logs
    recent_logs = db_manager.get_recent_logs("card_checks", user_id=12345, limit=5)
    print("Recent logs:", recent_logs)

    # Safely close the connection when done
    db_manager.close_connection()