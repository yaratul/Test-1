import time
import requests
from pymongo import MongoClient, errors
from server import MongoDBManager  # Import MongoDBManager from server.py

# Initialize MongoDBManager for admin features
db_manager = MongoDBManager()

# Load environment variables (e.g., ADMIN_ID)
from dotenv import load_dotenv
import os

load_dotenv()
ADMIN_ID = os.getenv('ADMIN_ID')

# Admin user ID for permissions
# Define roles and permissions
ALLOWED_USERS = {}  # Store user permissions {user_id: permission_status}
GROUP_PERMISSIONS = {}  # Manage group permissions {group_id: permission_status}
USER_IPS = {}  # Track users by IP addresses {user_id: ip_address}
BLACKLISTED_IPS = []  # Store blocked IPs

# Spam tracking and rate limiting
SPAM_THRESHOLD = 5  # Messages per minute allowed
USER_ACTIONS = {}  # Store user actions for tracking {user_id: [timestamps of messages]}
COOLDOWN_USERS = {}  # Track users on cooldown {user_id: cooldown_end_time}


### ADMINISTRATIVE COMMANDS ###

def allow_user(bot, message):
    """Allow a user to use the bot (Admin-only)."""
    if message.from_user.id == int(ADMIN_ID):
        try:
            user_id = int(message.text.split()[1])
            ALLOWED_USERS[user_id] = True
            db_manager.update_user_data("allowed_users", user_id, {"permission": "granted"})
            bot.reply_to(message, f"✅ User {user_id} is now allowed to use the bot.")
        except (IndexError, ValueError):
            bot.reply_to(message, "❌ Please provide a valid user ID.")
        except errors.PyMongoError as e:
            bot.reply_to(message, f"❌ Database error: {str(e)}")
    else:
        bot.reply_to(message, "❌ You are not authorized to run this command.")


def restrict_user(bot, message, reason="spamming"):
    """Restrict a user from using the bot (Admin-only)."""
    if message.from_user.id == int(ADMIN_ID):
        try:
            user_id = int(message.text.split()[1])
            ALLOWED_USERS[user_id] = False
            db_manager.update_user_data("allowed_users", user_id, {"permission": "restricted", "reason": reason})
            bot.reply_to(message, f"🚫 User {user_id} is restricted for: {reason}.")
        except (IndexError, ValueError):
            bot.reply_to(message, "❌ Please provide a valid user ID.")
        except errors.PyMongoError as e:
            bot.reply_to(message, f"❌ Database error: {str(e)}")
    else:
        bot.reply_to(message, "❌ You are not authorized to run this command.")


def allow_group(bot, message):
    """Allow a group to use the bot (Admin-only)."""
    if message.from_user.id == int(ADMIN_ID):
        group_id = message.chat.id
        GROUP_PERMISSIONS[group_id] = True
        db_manager.update_user_data("group_permissions", group_id, {"permission": "granted"})
        bot.reply_to(message, "✅ This group is now allowed to use the bot.")
    else:
        bot.reply_to(message, "❌ You are not authorized to run this command.")


def blacklist_ip(bot, message):
    """Blacklist an IP address (Admin-only)."""
    if message.from_user.id == int(ADMIN_ID):
        try:
            ip_address = message.text.split()[1]
            BLACKLISTED_IPS.append(ip_address)
            db_manager.insert_log("blacklisted_ips", {"ip_address": ip_address})
            bot.reply_to(message, f"🚫 IP {ip_address} has been blacklisted.")
        except IndexError:
            bot.reply_to(message, "❌ Please provide a valid IP address.")
        except errors.PyMongoError as e:
            bot.reply_to(message, f"❌ Database error: {str(e)}")
    else:
        bot.reply_to(message, "❌ You are not authorized to run this command.")


### SPAM PROTECTION AND USER MANAGEMENT ###

def get_user_ip(user_id):
    """Retrieve user's IP address (for tracking and blocking)."""
    try:
        user_ip = requests.get(f"https://api.ipify.org?user_id={user_id}").text
        return user_ip
    except requests.RequestException as e:
        print(f"❌ Error retrieving IP: {e}")
        return None


def detect_spam(bot, message):
    """Detect spam based on message frequency."""
    user_id = message.from_user.id
    current_time = time.time()

    # Check for cooldown
    if user_id in COOLDOWN_USERS and current_time < COOLDOWN_USERS[user_id]:
        bot.reply_to(message, "⏳ You are temporarily restricted for spamming. Try again later.")
        return True

    if user_id not in USER_ACTIONS:
        USER_ACTIONS[user_id] = []

    USER_ACTIONS[user_id].append(current_time)

    # Remove actions older than 1 minute
    USER_ACTIONS[user_id] = [timestamp for timestamp in USER_ACTIONS[user_id] if current_time - timestamp < 60]

    # Check spam threshold
    if len(USER_ACTIONS[user_id]) > SPAM_THRESHOLD:
        bot.reply_to(message, "🚫 You are restricted for spamming.")
        restrict_user(bot, message, reason="spamming")
        COOLDOWN_USERS[user_id] = current_time + 3600  # 1-hour cooldown
        return True
    return False


def is_ip_blacklisted(user_id):
    """Check if user's IP is blacklisted."""
    ip_address = get_user_ip(user_id)
    return ip_address in BLACKLISTED_IPS


### AUTOMATED RESTRICTIONS AND PERMISSIONS CHECKS ###

def handle_messages(bot, message):
    """Monitor user activity and apply restrictions or permissions as needed."""
    user_id = message.from_user.id

    # Check if user's IP is blacklisted
    if is_ip_blacklisted(user_id):
        bot.reply_to(message, "❌ Your IP is blacklisted.")
        return

    # Detect spamming and restrict if necessary
    if detect_spam(bot, message):
        return

    # Check if the group is allowed to use the bot
    if message.chat.type == 'group':
        if message.chat.id not in GROUP_PERMISSIONS or not GROUP_PERMISSIONS[message.chat.id]:
            bot.reply_to(message, "❌ This group is not allowed to use the bot.")
            return

    # Check if the user is allowed to use the bot
    if user_id not in ALLOWED_USERS or not ALLOWED_USERS[user_id]:
        bot.reply_to(message, "❌ You are not allowed to use the bot.")
        return

    # Normal bot behavior continues here...


### ADMIN MONITORING COMMANDS ###

def get_restricted_users(bot, message):
    """Get a list of restricted users (Admin-only)."""
    if message.from_user.id == int(ADMIN_ID):
        restricted_users = db_manager.get_user_data("allowed_users", {"permission": "restricted"})
        if restricted_users:
            bot.reply_to(message, f"🚫 Restricted Users: {restricted_users}")
        else:
            bot.reply_to(message, "✅ No users are currently restricted.")
    else:
        bot.reply_to(message, "❌ You are not authorized to run this command.")


def view_spam_alerts(bot, message):
    """View recent spam alerts (Admin-only)."""
    if message.from_user.id == int(ADMIN_ID):
        spam_alerts = db_manager.get_recent_logs("spam_alerts", user_id=None)
        if spam_alerts:
            bot.reply_to(message, f"📊 Spam Alerts: {spam_alerts}")
        else:
            bot.reply_to(message, "✅ No spam alerts at the moment.")
    else:
        bot.reply_to(message, "❌ You are not authorized to run this command.")